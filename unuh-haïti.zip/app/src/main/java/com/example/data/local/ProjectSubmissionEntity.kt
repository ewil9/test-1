package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projets_partenariats")
data class ProjectSubmissionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val titre: String,
    val organisation: String,
    val nomContact: String,
    val emailContact: String,
    val telephoneWhatsapp: String,
    val typeProposition: String,
    val description: String,
    val fichierNom: String?,
    val fichierUri: String?,
    val fichierTaille: Long = 0L,
    val dateDepot: Long = System.currentTimeMillis()
)
