package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages_contact")
data class ContactMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nom: String,
    val prenom: String,
    val message: String,
    val canal: String,
    val dateEnvoi: Long = System.currentTimeMillis()
)
