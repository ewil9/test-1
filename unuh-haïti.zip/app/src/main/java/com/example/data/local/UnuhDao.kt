package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UnuhDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity): Long

    @Query("SELECT * FROM etudiants_inscriptions ORDER BY dateInscription DESC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM etudiants_inscriptions WHERE classeNiveau = :classe ORDER BY dateInscription DESC")
    fun getStudentsByClasse(classe: String): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectSubmissionEntity): Long

    @Query("SELECT * FROM projets_partenariats ORDER BY dateDepot DESC")
    fun getAllProjects(): Flow<List<ProjectSubmissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactMessageEntity): Long

    @Query("SELECT * FROM messages_contact ORDER BY dateEnvoi DESC")
    fun getAllContacts(): Flow<List<ContactMessageEntity>>
}
