package com.example.data.model

data class CourseSubject(
    val id: String,
    val title: String,
    val level: CourseLevel,
    val iconName: String,
    val professor: String,
    val totalChapters: Int,
    val durationHours: String,
    val description: String,
    val keyTopics: List<String>,
    val pdfGuideTitle: String,
    val videoLessonsCount: Int
)

enum class CourseLevel(val label: String, val badgeColorHex: Long) {
    NS4("Nouveau Secondaire 4 (NS4)", 0xFF0493B5),
    NINTH_AF("9ème Année Fondamentale (9e AF)", 0xFF0D3B66)
}

object CourseDataProvider {
    val ns4Courses = listOf(
        CourseSubject(
            id = "ns4_math",
            title = "Mathématiques Avancées",
            level = CourseLevel.NS4,
            iconName = "Calculate",
            professor = "Prof. Ronald Celestin (U.N.U.H.)",
            totalChapters = 12,
            durationHours = "48h de cours",
            description = "Programme officiel du Baccalauréat haïtien : Suites numériques, limites et dérivation, intégration, géométrie dans l'espace et probabilités.",
            keyTopics = listOf(
                "1. Suites arithmétiques et géométriques",
                "2. Limites et continuité des fonctions",
                "3. Calcul différentiel et étude de courbes",
                "4. Nombres complexes et trigonométrie",
                "5. Géométrie analytique et vecteurs de l'espace",
                "6. Statistiques et probabilités au bac"
            ),
            pdfGuideTitle = "Guide_Complet_Maths_NS4_UNUH.pdf",
            videoLessonsCount = 24
        ),
        CourseSubject(
            id = "ns4_phy",
            title = "Physique & Mécanique",
            level = CourseLevel.NS4,
            iconName = "Bolt",
            professor = "Ing. Jean Marc Étienne",
            totalChapters = 10,
            durationHours = "40h de cours",
            description = "Préparation rigoureuse aux examens d'État : Cinématique, lois de Newton, travail et énergie, circuits RLC, optique ondulatoire.",
            keyTopics = listOf(
                "1. Cinématique du point matériel",
                "2. Dynamique et forces de frottement",
                "3. Énergie mécanique et conservation",
                "4. Électrostatique et loi de Coulomb",
                "5. Ondes mécaniques et optique ondulatoire"
            ),
            pdfGuideTitle = "Fiches_Formules_Physique_NS4.pdf",
            videoLessonsCount = 18
        ),
        CourseSubject(
            id = "ns4_chim",
            title = "Chimie Organique & Minérale",
            level = CourseLevel.NS4,
            iconName = "Science",
            professor = "Dr. Marie-Laure Moïse",
            totalChapters = 8,
            durationHours = "32h de cours",
            description = "Étude approfondie des réactions chimiques, chimie des composés du carbone, solutions aqueuses, pH-métrie et titrages.",
            keyTopics = listOf(
                "1. Nomenclature et hydrocarbures",
                "2. Fonctions oxygénées (Alcools, Aldéhydes, Acides)",
                "3. Équilibres chimiques et réactions acido-basiques",
                "4. Cinétique chimique et catalyseurs"
            ),
            pdfGuideTitle = "Synthese_Chimie_Organique_NS4.pdf",
            videoLessonsCount = 14
        ),
        CourseSubject(
            id = "ns4_philo",
            title = "Philosophie & Méthodologie",
            level = CourseLevel.NS4,
            iconName = "Psychology",
            professor = "Prof. Estime Wilguernsly",
            totalChapters = 9,
            durationHours = "36h de cours",
            description = "Maîtrise de la dissertation philosophique et du commentaire de texte. Exploration des grands thèmes : Conscience, Liberté, Morale, État et Vérité.",
            keyTopics = listOf(
                "1. Méthode pas-à-pas de la dissertation philosophique",
                "2. La Conscience et l'Inconscient",
                "3. Liberté, Nécessité et Responsabilité",
                "4. La Société, l'État et la Justice",
                "5. Anthologie des auteurs classiques et contemporains"
            ),
            pdfGuideTitle = "Manuel_Dissertation_Philo_Bac_UNUH.pdf",
            videoLessonsCount = 16
        ),
        CourseSubject(
            id = "ns4_bio",
            title = "Biologie & Géologie (SVT)",
            level = CourseLevel.NS4,
            iconName = "Spa",
            professor = "Agr. Patrick Desmangles",
            totalChapters = 7,
            durationHours = "28h de cours",
            description = "Génétique mendélienne et humaine, biosynthèse des protéines, tectonique des plaques et risques sismiques en Haïti.",
            keyTopics = listOf(
                "1. Structure de l'ADN et synthèse protéique",
                "2. Lois de transmission génétique de Mendel",
                "3. Immunologie et défenses de l'organisme",
                "4. Géologie et géodynamique de la plaque caribéenne"
            ),
            pdfGuideTitle = "Recueil_SVT_NS4_Haïti.pdf",
            videoLessonsCount = 12
        ),
        CourseSubject(
            id = "ns4_fr_lit",
            title = "Littérature & Français",
            level = CourseLevel.NS4,
            iconName = "MenuBook",
            professor = "Prof. Guerline François",
            totalChapters = 8,
            durationHours = "30h de cours",
            description = "Analyse littéraire approfondie, courants littéraires, auteurs haïtiens incontournables (Jacques Roumain, Jacques Stephen Alexis, etc.) et dissertation littéraire.",
            keyTopics = listOf(
                "1. Les mouvements littéraires (Romantisme, Réalisme, Indigénisme haïtien)",
                "2. Figures de style et procédés d'écriture",
                "3. Techniques de résumé et contraction de texte",
                "4. Étude de texte critique pour le baccalauréat"
            ),
            pdfGuideTitle = "Anthologie_Litterature_Haitienne_NS4.pdf",
            videoLessonsCount = 15
        )
    )

    val ninthAfCourses = listOf(
        CourseSubject(
            id = "9af_math",
            title = "Mathématiques Fondamentales",
            level = CourseLevel.NINTH_AF,
            iconName = "Calculate",
            professor = "Prof. Pierre Yves Delva",
            totalChapters = 10,
            durationHours = "42h de cours",
            description = "Programme officiel du MENFP pour la 9e AF : Fractions, puissances, factorisations, théorème de Pythagore, théorème de Thalès, géométrie plane.",
            keyTopics = listOf(
                "1. Nombres rationnels et calcul fractionnaire",
                "2. Équations et inéquations du 1er degré",
                "3. Théorème de Pythagore et applications",
                "4. Théorème de Thalès et triangles semblables",
                "5. Aires, périmètres et volumes"
            ),
            pdfGuideTitle = "Exercices_Corriges_Maths_9eAF.pdf",
            videoLessonsCount = 20
        ),
        CourseSubject(
            id = "9af_sciences",
            title = "Sciences Expérimentales",
            level = CourseLevel.NINTH_AF,
            iconName = "Biotech",
            professor = "Prof. Nadine Joseph",
            totalChapters = 9,
            durationHours = "35h de cours",
            description = "Sciences physiques et naturelles : États de la matière, mélanges, le système digestif, respiratoire et circulatoire, hygiène et environnement haïtien.",
            keyTopics = listOf(
                "1. Propriétés de la matière et transformations physiques",
                "2. Anatomie humaine et nutrition",
                "3. Les écosystèmes et la protection de l'environnement en Haïti",
                "4. Électricité de base et circuits simples"
            ),
            pdfGuideTitle = "Guide_Sciences_Experimentales_9eAF.pdf",
            videoLessonsCount = 15
        ),
        CourseSubject(
            id = "9af_soc",
            title = "Sciences Sociales & Histoire d'Haïti",
            level = CourseLevel.NINTH_AF,
            iconName = "AccountBalance",
            professor = "Prof. Jean Renel Saint-Fleur",
            totalChapters = 8,
            durationHours = "30h de cours",
            description = "Histoire glorieuse d'Haïti de la période coloniale à l'indépendance de 1804 et l'ère contemporaine, géographie physique d'Haïti et instruction civique.",
            keyTopics = listOf(
                "1. La révolution haïtienne et l'épopée de 1804",
                "2. Les héros nationaux (Toussaint, Dessalines, Christophe, Pétion)",
                "3. Géographie physique des 10 départements d'Haïti",
                "4. Éducation civique et institutions de la République"
            ),
            pdfGuideTitle = "Histoire_Geographie_Haiti_9eAF.pdf",
            videoLessonsCount = 14
        ),
        CourseSubject(
            id = "9af_kreyol",
            title = "Kominikasyon Kreyòl",
            level = CourseLevel.NINTH_AF,
            iconName = "RecordVoiceOver",
            professor = "Prof. Jacques-Edouard Baptiste",
            totalChapters = 8,
            durationHours = "28h de cours",
            description = "Gramè ofisyèl lang kreyòl la, lekti ak konpreyansyon tèks, òtograf kreyòl dapre Akademi Kreyòl Ayisyen, analiz pwovèb ak ekspresyon tradisyonèl.",
            keyTopics = listOf(
                "1. Alfabè ofisyèl ak règ òtograf kreyòl",
                "2. Klas mo ak estrikti fraz nan lang kreyòl la",
                "3. Lekti gide ak konpreyansyon tèks otè ayisyen",
                "4. Pwovèb, fab ak literati oral ayisyen"
            ),
            pdfGuideTitle = "Gramè_Kreyòl_Ofisyèl_9eAF.pdf",
            videoLessonsCount = 12
        ),
        CourseSubject(
            id = "9af_fr",
            title = "Communication Française",
            level = CourseLevel.NINTH_AF,
            iconName = "AutoStories",
            professor = "Mme Carole Beauvoir",
            totalChapters = 9,
            durationHours = "34h de cours",
            description = "Grammaire française, conjugaison des verbes usuels et irréguliers, enrichissement du vocabulaire, expression écrite et préparation à l'examen officiel.",
            keyTopics = listOf(
                "1. Accords du participe passé et temps verbaux",
                "2. Propositions subordonnées relatives et conjonctives",
                "3. Vocabulaire, homonymes, paronymes et synonymes",
                "4. Rédaction de paragraphe narratif et descriptif"
            ),
            pdfGuideTitle = "Recueil_Francais_Examen_9eAF.pdf",
            videoLessonsCount = 16
        ),
        CourseSubject(
            id = "9af_anglais",
            title = "Anglais & Espagnol",
            level = CourseLevel.NINTH_AF,
            iconName = "Translate",
            professor = "Prof. Samuel Altidor",
            totalChapters = 7,
            durationHours = "25h de cours",
            description = "Initiation aux langues vivantes étrangères requises aux épreuves officielles : vocabulaire courant, salutations, structures grammaticales de base.",
            keyTopics = listOf(
                "1. Basic English Grammar & Daily Vocabulary",
                "2. Reading comprehension exercises in English",
                "3. Gramática básica del español y diálogos",
                "4. Modèles de questions d'examens d'État"
            ),
            pdfGuideTitle = "Langues_Vivantes_9eAF_UNUH.pdf",
            videoLessonsCount = 10
        )
    )
}
