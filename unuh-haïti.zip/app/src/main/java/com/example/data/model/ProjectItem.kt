package com.example.data.model

data class InstitutionalProject(
    val id: String,
    val title: String,
    val category: String,
    val status: String,
    val location: String,
    val description: String,
    val objectives: List<String>,
    val targetAudience: String,
    val leadName: String
)

data class JobOffer(
    val id: String,
    val title: String,
    val type: String, // "Bénévolat", "Temps partiel", "Contrat académique", "Stage"
    val department: String,
    val location: String,
    val deadline: String,
    val requirements: List<String>,
    val contactEmail: String
)

object ProjectsDataProvider {
    val currentProjects = listOf(
        InstitutionalProject(
            id = "proj_biblio",
            title = "Bibliothèque Numérique Universitaire Haïtienne",
            category = "Éducation & Technologie",
            status = "En cours de déploiement",
            location = "National (Accessible en ligne partout en Haïti)",
            description = "Plateforme numérique libre donnant accès à plus de 5,000 manuels, mémoires universitaires, annales d'examens d'État (9e AF et Bac/NS4) et publications scientifiques d'auteurs haïtiens.",
            objectives = listOf(
                "Démocratiser l'accès aux manuels scolaires de référence",
                "Fournir des annales corrigées gratuites pour les 10 départements géographiques",
                "Créer une archive ouverte de la recherche universitaire haïtienne"
            ),
            targetAudience = "Élèves de 9e AF, NS4 et Étudiants universitaires",
            leadName = "Comité Scientifique U.N.U.H."
        ),
        InstitutionalProject(
            id = "proj_caravane",
            title = "Caravane Nationale d'Orientation Universitaire",
            category = "Orientation & Jeunesse",
            status = "Prochaine tournée : Nord & Sud",
            location = "Cap-Haïtien, Les Cayes, Gonaïves, Port-au-Prince",
            description = "Tournée académique guidant les bacheliers et élèves de NS4 vers les filières d'avenir (Génie, Médecine, Agronomie, Droit, Nouvelles Technologies) avec des simulations de concours d'admission.",
            objectives = listOf(
                "Accompagner plus de 3,000 bacheliers chaque année",
                "Réduire le taux d'échec aux concours des facultés publiques et privées",
                "Offrir des ateliers de mentorat avec des professionnels chevronnés"
            ),
            targetAudience = "Finissants NS4 et nouveaux bacheliers",
            leadName = "Direction des Projets U.N.U.H."
        ),
        InstitutionalProject(
            id = "proj_labo",
            title = "Laboratoires Scientifiques Itinérants",
            category = "Sciences Expérimentales",
            status = "Phase pilote active",
            location = "Écoles partenaires en milieu périurbain et rural",
            description = "Fourniture de kits de manipulation en chimie, physique et biologie pour permettre aux lycéens de réaliser les travaux pratiques requis pour les examens officiels du MENFP.",
            objectives = listOf(
                "Rapprocher l'expérimentation concrète de la théorie des manuels",
                "Former les enseignants aux travaux pratiques modernes à faible coût",
                "Susciter des vocations scientifiques chez les jeunes haïtiens"
            ),
            targetAudience = "Classes de 9e AF et NS4",
            leadName = "Département des Sciences U.N.U.H."
        ),
        InstitutionalProject(
            id = "proj_bourses",
            title = "Fonds de Solidarité & Bourses d'Excellence",
            category = "Solidarité Universitaire",
            status = "Appels à candidatures ouverts",
            location = "Haïti & Partenaires Internationaux",
            description = "Attribution de bourses d'études et de bourses de subsistance aux étudiants universitaires les plus méritants issus de milieux défavorisés.",
            objectives = listOf(
                "Soutenir 50 étudiants boursiers par an",
                "Financer les frais d'inscription universitaire et de recherche de mémoire",
                "Mettre en place un réseau d'anciens boursiers tuteurs solidaires"
            ),
            targetAudience = "Étudiants de premier et second cycles universitaires",
            leadName = "Estime Wilguernsly (Fondateur)"
        )
    )

    val jobAndRecruitmentOffers = listOf(
        JobOffer(
            id = "job_tuteur_math",
            title = "Tuteur / Enseignant de Mathématiques (NS4)",
            type = "Contrat Pédagogique / Vacations",
            department = "Département Pédagogique U.N.U.H.",
            location = "En ligne & Présentiel (Port-au-Prince)",
            deadline = "15 Décembre 2026",
            requirements = listOf(
                "Licence en Mathématiques, Génie ou Sciences Économiques",
                "Minimum 2 ans d'expérience dans l'enseignement secondaire ou cours de préparation au Bac",
                "Excellente pédagogie et maîtrise du programme officiel haïtien (NS4)",
                "Aisance avec les outils numériques (WhatsApp, Zoom, Classroom)"
            ),
            contactEmail = "uniondesuniversitairesdayiti@gmail.com"
        ),
        JobOffer(
            id = "job_coord_projets",
            title = "Coordonnateur de Projets Régionaux",
            type = "Temps Partiel / Bénévolat Valorisé",
            department = "Direction du Développement U.N.U.H.",
            location = "Départements : Nord, Artibonite, Sud",
            deadline = "30 Janvier 2027",
            requirements = listOf(
                "Étudiant en fin de cycle ou diplômé en Gestion, Sciences Sociales ou Gestion de Projets",
                "Dynamisme, leadership associatif prouvé et sens de l'organisation",
                "Capacité de mobilisation de la jeunesse et des structures scolaires locales",
                "Maîtrise du Français et du Créole"
            ),
            contactEmail = "uniondesuniversitairesdayiti@gmail.com"
        ),
        JobOffer(
            id = "job_dev_informatique",
            title = "Développeur Web & Mobile (Android / Web)",
            type = "Stage / Contribution Projet",
            department = "Pôle Numérique & Systèmes d'Information",
            location = "Télétravail / Hybride",
            deadline = "Permanent",
            requirements = listOf(
                "Connaissances en Kotlin / Jetpack Compose ou Web (React / Vue / PHP & MySQL)",
                "Sensibilité à l'accessibilité pour les utilisateurs en Haïti (faible bande passante)",
                "Volonté de contribuer activement à l'autonomie technologique de l'association",
                "Rigueur et esprit d'équipe"
            ),
            contactEmail = "uniondesuniversitairesdayiti@gmail.com"
        )
    )
}
