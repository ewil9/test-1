package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "etudiants_inscriptions")
data class StudentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val matricule: String,
    val nom: String,
    val prenom: String,
    val numeroWhatsapp: String,
    val sexe: String,
    val classeNiveau: String,
    val email: String,
    val modeConnexion: String,
    val dateInscription: Long = System.currentTimeMillis()
)
