package com.example.data.repository

import com.example.data.local.ContactMessageEntity
import com.example.data.local.ProjectSubmissionEntity
import com.example.data.local.StudentEntity
import com.example.data.local.UnuhDao
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UnuhRepository(private val dao: UnuhDao) {

    val allStudents: Flow<List<StudentEntity>> = dao.getAllStudents()
    val allProjects: Flow<List<ProjectSubmissionEntity>> = dao.getAllProjects()
    val allContacts: Flow<List<ContactMessageEntity>> = dao.getAllContacts()

    suspend fun registerStudent(
        nom: String,
        prenom: String,
        numeroWhatsapp: String,
        sexe: String,
        classeNiveau: String,
        email: String,
        modeConnexion: String
    ): StudentEntity {
        val cleanNumber = numeroWhatsapp.trim()
        val randomSuffix = (1000..9999).random()
        val year = SimpleDateFormat("yyyy", Locale.US).format(Date())
        val niveauCode = if (classeNiveau.contains("9e", ignoreCase = true)) "9AF" else "NS4"
        val matricule = "UNUH-$year-$niveauCode-$randomSuffix"

        val student = StudentEntity(
            matricule = matricule,
            nom = nom.trim(),
            prenom = prenom.trim(),
            numeroWhatsapp = cleanNumber,
            sexe = sexe,
            classeNiveau = classeNiveau,
            email = email.trim(),
            modeConnexion = modeConnexion
        )
        val id = dao.insertStudent(student)
        return student.copy(id = id)
    }

    suspend fun submitProjectProposal(
        titre: String,
        organisation: String,
        nomContact: String,
        emailContact: String,
        telephoneWhatsapp: String,
        typeProposition: String,
        description: String,
        fichierNom: String?,
        fichierUri: String?,
        fichierTaille: Long
    ): Long {
        val proposal = ProjectSubmissionEntity(
            titre = titre.trim(),
            organisation = organisation.trim(),
            nomContact = nomContact.trim(),
            emailContact = emailContact.trim(),
            telephoneWhatsapp = telephoneWhatsapp.trim(),
            typeProposition = typeProposition,
            description = description.trim(),
            fichierNom = fichierNom,
            fichierUri = fichierUri,
            fichierTaille = fichierTaille
        )
        return dao.insertProject(proposal)
    }

    suspend fun logContactMessage(
        nom: String,
        prenom: String,
        message: String,
        canal: String
    ): Long {
        val contact = ContactMessageEntity(
            nom = nom.trim(),
            prenom = prenom.trim(),
            message = message.trim(),
            canal = canal
        )
        return dao.insertContact(contact)
    }

    fun generateSqlScript(
        students: List<StudentEntity>,
        projects: List<ProjectSubmissionEntity>
    ): String {
        val sb = StringBuilder()
        sb.append("-- ==============================================================\n")
        sb.append("-- EXPORT SQL DES DONNÉES - UNION DES UNIVERSITAIRES D'HAÏTI\n")
        sb.append("-- Généré automatiquement le : ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
        sb.append("-- Propriétaire : Estime Wilguernsly | UNUH Haïti\n")
        sb.append("-- ==============================================================\n\n")

        sb.append("-- Table : etudiants_inscriptions (${students.size} enregistrement(s))\n")
        if (students.isNotEmpty()) {
            sb.append("INSERT INTO `etudiants_inscriptions` (`matricule`, `nom`, `prenom`, `numero_whatsapp`, `sexe`, `classe_niveau`, `email`, `mode_connexion`)\nVALUES\n")
            students.forEachIndexed { index, s ->
                val sep = if (index == students.lastIndex) ";" else ","
                sb.append("('${escapeSql(s.matricule)}', '${escapeSql(s.nom)}', '${escapeSql(s.prenom)}', '${escapeSql(s.numeroWhatsapp)}', '${escapeSql(s.sexe)}', '${escapeSql(s.classeNiveau)}', '${escapeSql(s.email)}', '${escapeSql(s.modeConnexion)}')$sep\n")
            }
        } else {
            sb.append("-- (Aucun nouvel étudiant inscrit dans la base locale pour l'instant)\n")
        }

        sb.append("\n-- Table : projets_partenariats (${projects.size} proposition(s))\n")
        if (projects.isNotEmpty()) {
            sb.append("INSERT INTO `projets_partenariats` (`titre_projet`, `organisation`, `nom_contact`, `email_contact`, `telephone_whatsapp`, `type_proposition`, `description`, `fichier_nom`, `fichier_taille_octets`)\nVALUES\n")
            projects.forEachIndexed { index, p ->
                val sep = if (index == projects.lastIndex) ";" else ","
                sb.append("('${escapeSql(p.titre)}', '${escapeSql(p.organisation)}', '${escapeSql(p.nomContact)}', '${escapeSql(p.emailContact)}', '${escapeSql(p.telephoneWhatsapp)}', '${escapeSql(p.typeProposition)}', '${escapeSql(p.description)}', '${escapeSql(p.fichierNom ?: "aucun")}', ${p.fichierTaille})$sep\n")
            }
        } else {
            sb.append("-- (Aucune proposition soumise pour l'instant)\n")
        }

        return sb.toString()
    }

    private fun escapeSql(input: String): String {
        return input.replace("'", "''").replace("\\", "\\\\")
    }
}
