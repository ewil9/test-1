package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        StudentEntity::class,
        ProjectSubmissionEntity::class,
        ContactMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class UnuhDatabase : RoomDatabase() {

    abstract fun unuhDao(): UnuhDao

    companion object {
        @Volatile
        private var INSTANCE: UnuhDatabase? = null

        fun getDatabase(context: Context): UnuhDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UnuhDatabase::class.java,
                    "unuh_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
