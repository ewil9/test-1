package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// UNUH Brand Palette inspired by the official logo
val UnuhCyanPrimary = Color(0xFF0493B5)
val UnuhCyanDark = Color(0xFF026D87)
val UnuhNavySecondary = Color(0xFF0D3B66)
val UnuhGoldAccent = Color(0xFFE5A93C)
val UnuhGoldLight = Color(0xFFFEE685)
val UnuhCyanLight = Color(0xFFE0F4F8)

val BackgroundLight = Color(0xFFF7FBFD)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF6F8)
val OnSurfaceLight = Color(0xFF132830)
val OutlineLight = Color(0xFFB5D4DC)

val BackgroundDark = Color(0xFF0A1820)
val SurfaceDark = Color(0xFF12232E)
val SurfaceVariantDark = Color(0xFF1D3545)
val OnSurfaceDark = Color(0xFFE2F0F4)
val OutlineDark = Color(0xFF33586E)
