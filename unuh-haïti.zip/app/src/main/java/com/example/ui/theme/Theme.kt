package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = UnuhCyanPrimary,
    onPrimary = Color.White,
    primaryContainer = UnuhCyanDark,
    onPrimaryContainer = Color.White,
    secondary = UnuhNavySecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1E3A5F),
    onSecondaryContainer = Color.White,
    tertiary = UnuhGoldAccent,
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF5E4300),
    onTertiaryContainer = UnuhGoldLight,
    background = BackgroundDark,
    onBackground = OnSurfaceDark,
    surface = SurfaceDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = Color(0xFFB0CDD6),
    outline = OutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = UnuhCyanPrimary,
    onPrimary = Color.White,
    primaryContainer = UnuhCyanLight,
    onPrimaryContainer = UnuhCyanDark,
    secondary = UnuhNavySecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E8FA),
    onSecondaryContainer = Color(0xFF0D3B66),
    tertiary = UnuhGoldAccent,
    onTertiary = Color.Black,
    tertiaryContainer = UnuhGoldLight,
    onTertiaryContainer = Color(0xFF4C3600),
    background = BackgroundLight,
    onBackground = OnSurfaceLight,
    surface = SurfaceLight,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = Color(0xFF385764),
    outline = OutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
