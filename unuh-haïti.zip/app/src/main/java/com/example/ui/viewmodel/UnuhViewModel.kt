package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectSubmissionEntity
import com.example.data.local.StudentEntity
import com.example.data.local.UnuhDatabase
import com.example.data.model.CourseLevel
import com.example.data.model.CourseSubject
import com.example.data.repository.UnuhRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder

enum class UnuhScreen(val title: String) {
    ACCUEIL("Accueil"),
    COURS("Cours en ligne"),
    PROJETS("Projets"),
    CONNEXION("Connexion"),
    A_PROPOS("Qui sommes-nous"),
    CONTACT("Contact")
}

class UnuhViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: UnuhRepository

    init {
        val database = UnuhDatabase.getDatabase(application)
        repository = UnuhRepository(database.unuhDao())
    }

    // Navigation
    private val _currentScreen = MutableStateFlow(UnuhScreen.ACCUEIL)
    val currentScreen: StateFlow<UnuhScreen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: UnuhScreen) {
        _currentScreen.value = screen
    }

    // Database Flows
    val studentsList: StateFlow<List<StudentEntity>> = repository.allStudents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val projectsList: StateFlow<List<ProjectSubmissionEntity>> = repository.allProjects.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current Logged-in Student
    private val _currentStudent = MutableStateFlow<StudentEntity?>(null)
    val currentStudent: StateFlow<StudentEntity?> = _currentStudent.asStateFlow()

    // Auth & Inscription Form State
    var isLoginMode = MutableStateFlow(true)
        private set

    val regNom = MutableStateFlow("")
    val regPrenom = MutableStateFlow("")
    val regWhatsapp = MutableStateFlow("")
    val regSexe = MutableStateFlow("Masculin") // "Masculin" or "Féminin"
    val regClasse = MutableStateFlow("NS4") // "NS4" or "9e AF"
    val regEmail = MutableStateFlow("")
    val loginEmail = MutableStateFlow("")
    val loginPassword = MutableStateFlow("")

    val authErrorMessage = MutableStateFlow<String?>(null)
    val authSuccessMessage = MutableStateFlow<String?>(null)

    fun toggleAuthMode() {
        isLoginMode.value = !isLoginMode.value
        authErrorMessage.value = null
        authSuccessMessage.value = null
    }

    fun setAuthMode(login: Boolean) {
        isLoginMode.value = login
        authErrorMessage.value = null
    }

    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            // Emulate Google Sign In and auto-fill account
            val student = repository.registerStudent(
                nom = "Étudiant",
                prenom = "Google Connecté",
                numeroWhatsapp = "+509 4354-0140",
                sexe = "Masculin",
                classeNiveau = "NS4",
                email = "etudiant.univ@gmail.com",
                modeConnexion = "Google Sign-In"
            )
            _currentStudent.value = student
            authSuccessMessage.value = "Connecté avec succès via Google !"
            Toast.makeText(context, "Bienvenue, ${student.prenom} !", Toast.LENGTH_SHORT).show()
        }
    }

    fun signInWithEmail(context: Context) {
        val email = loginEmail.value.trim()
        val password = loginPassword.value.trim()
        if (email.isBlank() || password.isBlank()) {
            authErrorMessage.value = "Veuillez renseigner votre email et mot de passe."
            return
        }

        viewModelScope.launch {
            // Check if existing student or sign in
            val existing = studentsList.value.firstOrNull { it.email.equals(email, ignoreCase = true) }
            if (existing != null) {
                _currentStudent.value = existing
            } else {
                val student = repository.registerStudent(
                    nom = email.substringBefore("@").replaceFirstChar { it.uppercase() },
                    prenom = "Étudiant",
                    numeroWhatsapp = "+509 3000-0000",
                    sexe = "Masculin",
                    classeNiveau = "NS4",
                    email = email,
                    modeConnexion = "Email"
                )
                _currentStudent.value = student
            }
            authSuccessMessage.value = "Connexion réussie !"
            Toast.makeText(context, "Session active !", Toast.LENGTH_SHORT).show()
        }
    }

    fun submitRegistration(context: Context) {
        val nom = regNom.value.trim()
        val prenom = regPrenom.value.trim()
        val whatsapp = regWhatsapp.value.trim()
        val sexe = regSexe.value
        val classe = regClasse.value
        val email = regEmail.value.trim().ifBlank { "${prenom.lowercase()}.${nom.lowercase()}@etudiant.ht" }

        if (nom.isBlank() || prenom.isBlank() || whatsapp.isBlank()) {
            authErrorMessage.value = "Veuillez remplir le Nom, Prénom et Numéro WhatsApp."
            return
        }

        viewModelScope.launch {
            val student = repository.registerStudent(
                nom = nom,
                prenom = prenom,
                numeroWhatsapp = whatsapp,
                sexe = sexe,
                classeNiveau = classe,
                email = email,
                modeConnexion = "Formulaire Inscription"
            )
            _currentStudent.value = student
            authSuccessMessage.value = "Inscription réussie ! Votre matricule : ${student.matricule}"
            Toast.makeText(context, "Compte créé pour $prenom $nom !", Toast.LENGTH_LONG).show()

            // Reset form
            regNom.value = ""
            regPrenom.value = ""
            regWhatsapp.value = ""
            regEmail.value = ""
        }
    }

    fun logout() {
        _currentStudent.value = null
        authSuccessMessage.value = null
        authErrorMessage.value = null
    }

    // Course Selection State
    val selectedCourseLevel = MutableStateFlow(CourseLevel.NS4)
    val viewingSubjectDetail = MutableStateFlow<CourseSubject?>(null)

    fun selectCourseLevel(level: CourseLevel) {
        selectedCourseLevel.value = level
    }

    fun openSubjectDetail(subject: CourseSubject) {
        viewingSubjectDetail.value = subject
    }

    fun closeSubjectDetail() {
        viewingSubjectDetail.value = null
    }

    // Projects & Partnership Submission State
    val projTitre = MutableStateFlow("")
    val projOrganisation = MutableStateFlow("")
    val projNomContact = MutableStateFlow("")
    val projEmailContact = MutableStateFlow("")
    val projPhoneContact = MutableStateFlow("")
    val projType = MutableStateFlow("Partenariat")
    val projDescription = MutableStateFlow("")

    val attachedFileName = MutableStateFlow<String?>(null)
    val attachedFileUri = MutableStateFlow<String?>(null)
    val attachedFileSize = MutableStateFlow(0L)
    val projectSubmitSuccess = MutableStateFlow(false)

    fun setAttachedFile(name: String, uriString: String, sizeBytes: Long) {
        attachedFileName.value = name
        attachedFileUri.value = uriString
        attachedFileSize.value = sizeBytes
    }

    fun removeAttachedFile() {
        attachedFileName.value = null
        attachedFileUri.value = null
        attachedFileSize.value = 0L
    }

    fun submitProjectProposal(context: Context) {
        val titre = projTitre.value.trim()
        val org = projOrganisation.value.trim()
        val nom = projNomContact.value.trim()
        val email = projEmailContact.value.trim()
        val phone = projPhoneContact.value.trim()
        val type = projType.value
        val desc = projDescription.value.trim()

        if (titre.isBlank() || org.isBlank() || nom.isBlank() || (email.isBlank() && phone.isBlank())) {
            Toast.makeText(context, "Veuillez remplir les informations obligatoires du projet.", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            repository.submitProjectProposal(
                titre = titre,
                organisation = org,
                nomContact = nom,
                emailContact = email,
                telephoneWhatsapp = phone,
                typeProposition = type,
                description = desc,
                fichierNom = attachedFileName.value,
                fichierUri = attachedFileUri.value,
                fichierTaille = attachedFileSize.value
            )
            projectSubmitSuccess.value = true
            Toast.makeText(context, "Votre dossier a été transmis avec succès !", Toast.LENGTH_LONG).show()

            // Reset inputs
            projTitre.value = ""
            projOrganisation.value = ""
            projNomContact.value = ""
            projEmailContact.value = ""
            projPhoneContact.value = ""
            projDescription.value = ""
            attachedFileName.value = null
            attachedFileUri.value = null
            attachedFileSize.value = 0L
        }
    }

    fun resetProjectSuccessNotice() {
        projectSubmitSuccess.value = false
    }

    // Contact Form State
    val contactNom = MutableStateFlow("")
    val contactPrenom = MutableStateFlow("")
    val contactMessage = MutableStateFlow("")

    fun sendContactViaWhatsapp(context: Context) {
        val nom = contactNom.value.trim()
        val prenom = contactPrenom.value.trim()
        val msg = contactMessage.value.trim()

        if (nom.isBlank() && prenom.isBlank() && msg.isBlank()) {
            Toast.makeText(context, "Veuillez renseigner votre nom et votre message.", Toast.LENGTH_SHORT).show()
            return
        }

        val textPayload = buildString {
            append("Bonjour U.N.U.H. (Union des Universitaires d'Haïti),\n\n")
            if (nom.isNotBlank() || prenom.isNotBlank()) {
                append("Je m'appelle : $prenom $nom\n")
            }
            append("Message :\n$msg")
        }

        viewModelScope.launch {
            repository.logContactMessage(
                nom = nom.ifBlank { "Anonyme" },
                prenom = prenom,
                message = msg,
                canal = "WhatsApp"
            )
        }

        val encoded = try {
            URLEncoder.encode(textPayload, "UTF-8")
        } catch (_: Exception) {
            textPayload
        }

        val whatsappNumber = "50943540140"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?phone=$whatsappNumber&text=$encoded")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$whatsappNumber?text=$encoded")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                context.startActivity(browserIntent)
            } catch (_: Exception) {
                Toast.makeText(context, "WhatsApp n'a pas pu être ouvert sur cet appareil.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun sendContactViaEmail(context: Context) {
        val nom = contactNom.value.trim()
        val prenom = contactPrenom.value.trim()
        val msg = contactMessage.value.trim()

        if (nom.isBlank() && prenom.isBlank() && msg.isBlank()) {
            Toast.makeText(context, "Veuillez renseigner votre nom et votre message.", Toast.LENGTH_SHORT).show()
            return
        }

        val targetEmail = "uniondesuniversitairesdayiti@gmail.com"
        val subject = "Contact UNUH - $prenom $nom"
        val body = "Bonjour,\n\nJe suis $prenom $nom.\n\n$msg\n\nEnvoyé depuis l'application officielle UNUH Haïti."

        viewModelScope.launch {
            repository.logContactMessage(
                nom = nom.ifBlank { "Anonyme" },
                prenom = prenom,
                message = msg,
                canal = "Email"
            )
        }

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$targetEmail")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Aucune application de messagerie trouvée.", Toast.LENGTH_SHORT).show()
        }
    }

    // Admin Security & Access Control
    val isAdminLoggedIn = MutableStateFlow(false)
    val showAdminLoginDialog = MutableStateFlow(false)
    val showAdminPortal = MutableStateFlow(false)
    val adminPasswordInput = MutableStateFlow("")
    val adminPasswordError = MutableStateFlow<String?>(null)

    // Accepted Administrator Master Keys for Estime Wilguernsly
    private val validAdminKeys = setOf("unuh2026", "estime2026", "admin123", "Wilguernsly2026")

    fun openAdminLoginDialog() {
        adminPasswordInput.value = ""
        adminPasswordError.value = null
        showAdminLoginDialog.value = true
    }

    fun closeAdminLoginDialog() {
        showAdminLoginDialog.value = false
        adminPasswordError.value = null
    }

    fun loginAsAdmin(context: Context): Boolean {
        val entered = adminPasswordInput.value.trim()
        if (validAdminKeys.any { it.equals(entered, ignoreCase = true) }) {
            isAdminLoggedIn.value = true
            showAdminLoginDialog.value = false
            adminPasswordError.value = null
            openAdminPortal()
            Toast.makeText(context, "Session Administrateur active (Estime Wilguernsly)", Toast.LENGTH_SHORT).show()
            return true
        } else {
            adminPasswordError.value = "Mot de passe administrateur incorrect."
            return false
        }
    }

    fun logoutAdmin() {
        isAdminLoggedIn.value = false
        showAdminPortal.value = false
        showSqlViewer.value = false
    }

    fun openAdminPortal() {
        if (isAdminLoggedIn.value) {
            refreshSqlExport()
            showAdminPortal.value = true
        } else {
            openAdminLoginDialog()
        }
    }

    fun closeAdminPortal() {
        showAdminPortal.value = false
    }

    // SQL Viewer State (Exclusively accessible by authenticated Admin)
    val showSqlViewer = MutableStateFlow(false)
    val generatedSqlScript = MutableStateFlow("")

    fun refreshSqlExport() {
        val sql = repository.generateSqlScript(
            students = studentsList.value,
            projects = projectsList.value
        )
        generatedSqlScript.value = sql
    }

    fun openSqlExport() {
        if (!isAdminLoggedIn.value) {
            openAdminLoginDialog()
            return
        }
        refreshSqlExport()
        showSqlViewer.value = true
    }

    fun closeSqlExport() {
        showSqlViewer.value = false
    }
}
