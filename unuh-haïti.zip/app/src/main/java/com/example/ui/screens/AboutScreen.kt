package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Diversity3
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.UnuhCyanDark
import com.example.ui.theme.UnuhCyanLight
import com.example.ui.theme.UnuhCyanPrimary
import com.example.ui.theme.UnuhGoldAccent
import com.example.ui.theme.UnuhGoldLight
import com.example.ui.theme.UnuhNavySecondary

@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("about_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // En-tête avec Logo et Nom de l'organisation
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(UnuhNavySecondary, UnuhCyanDark, UnuhCyanPrimary)
                            )
                        )
                        .padding(22.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(CircleShape)
                                .border(3.dp, UnuhGoldAccent, CircleShape)
                                .background(Color.White)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_unuh),
                                contentDescription = "Emblème UNUH",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "UNION DES UNIVERSITAIRES D'HAÏTI",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = Color.White
                            ),
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "U.N.U.H.",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = UnuhGoldLight
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.35f)
                        ) {
                            Text(
                                text = "Propriété de Estime Wilguernsly",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = UnuhGoldLight,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Histoire de l'U.N.U.H.
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(UnuhCyanPrimary.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = UnuhCyanPrimary)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Histoire & Genèse de l'U.N.U.H.",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "L'Union des Universitaires d'Haïti (U.N.U.H.) est une organisation universitaire haïtienne fondée par Estime Wilguernsly, animée par une conviction profonde : la renaissance économique, sociale et institutionnelle d'Haïti passe impérativement par la démocratisation du savoir et l'élévation du niveau intellectuel de sa jeunesse.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Constatant les disparités criantes d'accès à l'éducation de qualité entre la capitale et les provinces, ainsi que le taux d'échec préoccupant aux examens officiels d'État (9e Année Fondamentale et Nouveau Secondaire 4 / Baccalauréat), Estime Wilguernsly a mobilisé enseignants, étudiants diplômés et universitaires passionnés pour créer un cadre d'entraide républicain.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Aujourd'hui, l'U.N.U.H. est devenue une référence incontournable grâce à ses cours de renforcement en ligne, ses tournées départementales d'orientation et ses projets structurants pour l'éducation en Haïti.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }

        // Symbolisme de l'Emblème et du Logo
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(UnuhGoldAccent.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = UnuhGoldAccent)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Symbolisme de l'Emblème U.N.U.H.",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SymbolItem(
                        symbol = "La Plume Centrale & Toque",
                        meaning = "Représente le génie intellectuel, la liberté d'expression par l'écrit, et le triomphe de la graduation universitaire."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SymbolItem(
                        symbol = "La Couronne de Lauriers",
                        meaning = "Symbole antique de victoire académique, d'excellence morale et d'honneur conféré aux lauréats méritants."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SymbolItem(
                        symbol = "Les Étoiles au Sommet",
                        meaning = "Guidance éthique, illumination spirituelle et aspiration continue vers les plus hauts sommets de la science."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SymbolItem(
                        symbol = "Le Bleu Océanique Profond",
                        meaning = "Inspiré de la mer caribéenne qui baigne Haïti, symbole de profondeur de réflexion, de sérénité et de fidélité à la patrie."
                    )
                }
            }
        }

        // Mission et Vision
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = UnuhCyanLight.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.School, contentDescription = null, tint = UnuhCyanDark)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Notre Mission",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = UnuhCyanDark)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Fournir un accompagnement pédagogique d'élite aux élèves de 9e AF et NS4, tout en facilitant l'accès aux bourses universitaires.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = UnuhNavySecondary.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = UnuhNavySecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Notre Vision",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = UnuhNavySecondary)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Bâtir une république du savoir où chaque jeune haïtien talentueux dispose des outils pour devenir leader et bâtisseur de la nation.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp)
                        )
                    }
                }
            }
        }

        // Valeurs Fondamentales
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Nos Valeurs Cardinales",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    ValueRow(title = "Excellence Académique", description = "Rigueur des cours, préparation méthodologique approfondie et dépassement de soi.")
                    ValueRow(title = "Solidarité Patriotique", description = "Mise en commun des savoirs au service du développement endogène d'Haïti.")
                    ValueRow(title = "Équité & Accessibilité", description = "Une éducation de haut niveau accessible à tous, sans distinction d'origine sociale.")
                    ValueRow(title = "Intégrité & Déontologie", description = "Respect scrupuleux des normes éthiques et lutte contre la fraude académique.")
                }
            }
        }
    }
}

@Composable
private fun SymbolItem(symbol: String, meaning: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = UnuhCyanPrimary,
            modifier = Modifier
                .size(16.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = symbol,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = UnuhCyanDark)
            )
            Text(
                text = meaning,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
        }
    }
}

@Composable
private fun ValueRow(title: String, description: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = "• $title",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = UnuhNavySecondary)
        )
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            ),
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}
