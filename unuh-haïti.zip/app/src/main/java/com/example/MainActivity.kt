package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.ContactMail
import androidx.compose.material.icons.filled.Diversity3
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.UnuhTopBar
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AdminLoginDialog
import com.example.ui.screens.AdminPortalDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ContactScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.SqlViewerDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.UnuhCyanPrimary
import com.example.ui.theme.UnuhNavySecondary
import com.example.ui.viewmodel.UnuhScreen
import com.example.ui.viewmodel.UnuhViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: UnuhViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                UnuhApp(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val screen: UnuhScreen,
    val icon: ImageVector,
    val label: String
)

@Composable
fun UnuhApp(viewModel: UnuhViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val showSqlViewer by viewModel.showSqlViewer.collectAsState()
    val showAdminLoginDialog by viewModel.showAdminLoginDialog.collectAsState()
    val showAdminPortal by viewModel.showAdminPortal.collectAsState()
    val sqlText by viewModel.generatedSqlScript.collectAsState()

    // BackHandler: return to Accueil if user is on a secondary screen
    BackHandler(enabled = currentScreen != UnuhScreen.ACCUEIL) {
        viewModel.navigateTo(UnuhScreen.ACCUEIL)
    }

    val navItems = listOf(
        NavItem(UnuhScreen.ACCUEIL, Icons.Default.Home, "Accueil"),
        NavItem(UnuhScreen.COURS, Icons.Default.School, "Cours"),
        NavItem(UnuhScreen.PROJETS, Icons.Default.Assignment, "Projets"),
        NavItem(UnuhScreen.CONNEXION, Icons.Default.Person, "Compte"),
        NavItem(UnuhScreen.A_PROPOS, Icons.Default.Diversity3, "UNUH"),
        NavItem(UnuhScreen.CONTACT, Icons.Default.ContactMail, "Contact")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            UnuhTopBar(
                title = currentScreen.title,
                onOpenAdmin = { viewModel.openAdminPortal() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = MaterialTheme.colorScheme.surfaceTint.let { 4.dp },
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                navItems.forEach { item ->
                    val isSelected = currentScreen == item.screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(item.screen) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = UnuhCyanPrimary,
                            selectedTextColor = UnuhCyanPrimary,
                            indicatorColor = UnuhCyanPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_item_${item.screen.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentScreen,
            modifier = Modifier.padding(innerPadding),
            label = "screen_transition"
        ) { screen ->
            when (screen) {
                UnuhScreen.ACCUEIL -> HomeScreen(viewModel = viewModel)
                UnuhScreen.COURS -> CoursesScreen(viewModel = viewModel)
                UnuhScreen.PROJETS -> ProjectsScreen(viewModel = viewModel)
                UnuhScreen.CONNEXION -> AuthScreen(viewModel = viewModel)
                UnuhScreen.A_PROPOS -> AboutScreen()
                UnuhScreen.CONTACT -> ContactScreen(viewModel = viewModel)
            }
        }
    }

    // Modal de connexion Administrateur (Estime Wilguernsly)
    if (showAdminLoginDialog) {
        AdminLoginDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.closeAdminLoginDialog() }
        )
    }

    // Portail Administrateur Privé (Accès exclusif SQL & Données)
    if (showAdminPortal) {
        AdminPortalDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.closeAdminPortal() }
        )
    }

    // Modal de visualisation directe SQL (uniquement après authentification)
    if (showSqlViewer) {
        SqlViewerDialog(
            sqlText = sqlText,
            onDismiss = { viewModel.closeSqlExport() }
        )
    }
}
