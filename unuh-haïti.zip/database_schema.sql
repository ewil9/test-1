-- ==============================================================================
-- UNION DES UNIVERSITAIRES D'HAITI (U.N.U.H.)
-- Propriétaire & Fondateur : Estime Wilguernsly
-- Contact : +50943540140 | uniondesuniversitairesdayiti@gmail.com
-- ==============================================================================
-- Script SQL de création de base de données pour le serveur et le code source.
-- Compatible avec MySQL 8.x, MariaDB 10.x, et facilement adaptable à PostgreSQL.
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `unuh_database`
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `unuh_database`;

-- ------------------------------------------------------------------------------
-- 1. Table des Inscriptions / Utilisateurs (Étudiants 9e AF, NS4, Universitaires)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `etudiants_inscriptions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `matricule` VARCHAR(30) UNIQUE NOT NULL,
    `nom` VARCHAR(100) NOT NULL,
    `prenom` VARCHAR(100) NOT NULL,
    `numero_whatsapp` VARCHAR(25) NOT NULL,
    `sexe` ENUM('Masculin', 'Feminin', 'Autre') NOT NULL,
    `classe_niveau` ENUM('9e AF', 'NS4', 'Universitaire', 'Autre') NOT NULL,
    `email` VARCHAR(150) NULL,
    `mode_connexion` VARCHAR(50) DEFAULT 'Formulaire Inscription',
    `statut_compte` ENUM('Actif', 'En_Attente', 'Suspendu') DEFAULT 'Actif',
    `date_inscription` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `derniere_connexion` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_whatsapp` (`numero_whatsapp`),
    INDEX `idx_classe` (`classe_niveau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2. Table des Projets, Partenariats, Financements et Dépôts de Fichiers (PDF)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projets_partenariats` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `titre_projet` VARCHAR(200) NOT NULL,
    `organisation` VARCHAR(150) NOT NULL,
    `nom_contact` VARCHAR(100) NOT NULL,
    `email_contact` VARCHAR(150) NOT NULL,
    `telephone_whatsapp` VARCHAR(25) NOT NULL,
    `type_proposition` ENUM('Partenariat', 'Financement_Don', 'Offre_Emploi', 'Demande_Stage', 'Lettre_Ouverte') NOT NULL,
    `description` TEXT NOT NULL,
    `fichier_nom` VARCHAR(255) NULL COMMENT 'Nom original du fichier PDF attaché',
    `fichier_chemin` VARCHAR(500) NULL COMMENT 'Chemin relatif de stockage sur le serveur (ex: /uploads/pdf/...)',
    `fichier_taille_octets` BIGINT DEFAULT 0,
    `statut_traitement` ENUM('Recu', 'En_Examen', 'Approuve', 'Refuse') DEFAULT 'Recu',
    `date_depot` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_type_proposition` (`type_proposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3. Table des Messages de Contact (WhatsApp & Email)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `messages_contact` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nom` VARCHAR(100) NOT NULL,
    `prenom` VARCHAR(100) NOT NULL,
    `message` TEXT NOT NULL,
    `canal_envoi` ENUM('WhatsApp', 'Email', 'Formulaire_Direct') NOT NULL,
    `destinataire_whatsapp` VARCHAR(25) DEFAULT '+50943540140',
    `destinataire_email` VARCHAR(150) DEFAULT 'uniondesuniversitairesdayiti@gmail.com',
    `date_envoi` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 4. Exemples de requêtes de consultation pour votre serveur / code source
-- ------------------------------------------------------------------------------

-- Récupérer tous les élèves inscrits en NS4 :
-- SELECT * FROM `etudiants_inscriptions` WHERE `classe_niveau` = 'NS4' ORDER BY `date_inscription` DESC;

-- Récupérer tous les élèves inscrits en 9e AF :
-- SELECT * FROM `etudiants_inscriptions` WHERE `classe_niveau` = '9e AF' ORDER BY `date_inscription` DESC;

-- Récupérer les propositions de partenariat et fichiers PDF déposés :
-- SELECT `id`, `titre_projet`, `organisation`, `nom_contact`, `fichier_nom`, `fichier_chemin`, `date_depot`
-- FROM `projets_partenariats` ORDER BY `date_depot` DESC;

-- Insérer une nouvelle inscription test :
INSERT INTO `etudiants_inscriptions` (`matricule`, `nom`, `prenom`, `numero_whatsapp`, `sexe`, `classe_niveau`, `email`, `mode_connexion`)
VALUES
('UNUH-2026-001', 'Pierre', 'Jean-Baptiste', '+50936123456', 'Masculin', 'NS4', 'jean.pierre@example.ht', 'Google'),
('UNUH-2026-002', 'Auguste', 'Rose-Mirlène', '+50948987654', 'Feminin', '9e AF', 'rose.auguste@example.ht', 'Email');

-- Insérer une proposition test :
INSERT INTO `projets_partenariats` (`titre_projet`, `organisation`, `nom_contact`, `email_contact`, `telephone_whatsapp`, `type_proposition`, `description`, `fichier_nom`, `fichier_chemin`, `fichier_taille_octets`)
VALUES
('Projet Laboratoire Mobile en Haïti', 'Fondation Éducation Haïti', 'Dr. Philippe Moïse', 'partenariat@educationhaiti.org', '+50942000000', 'Partenariat', 'Proposition de partenariat pour le déploiement de kits de physique-chimie pour les élèves de NS4.', 'partenariat_unuh_labo_2026.pdf', '/uploads/pdf/partenariat_unuh_labo_2026.pdf', 1450890);
